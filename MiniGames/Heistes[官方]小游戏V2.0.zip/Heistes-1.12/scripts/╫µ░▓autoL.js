var ClassProvider = Java.type('net.ccbluex.liquidbounce.utils.MinecraftInstance');
var target = null;
var script = registerScript({
    name: '祖安AutoL',
    version: '0.0.0',
    authors: ['Kevin(Liquid_Bounce-jiege)']
});

var wd = ["Por qué no descargar el paquete de líquidos gratis！",
        "Dirección de descarga: liquidbounce.net ccbluex en yt!",
        "¿Abrir un hacker es mi hobby, cuál es tu hobby?",
        "Deja que Jackie te enseñe a ascender a Lang！",
        "¡Ven a mostrarme!!",
        "Me amas, te amo.",
        "Miel nieve ciudad de hielo dulce miel!",
        "Lo siento, no puedo evitar no matarte！",
		"Ja, ja, ja, perdedor！",
		"¡Mira!Puedo volar.",
		"Sé que estás en España, estoy en China, no puedo hacerte daño.",
		"Arrastrándose, tratando de matarme, de ninguna manera!",
		"Wow, estás muerto.",
        "Podría estar prohibido, y vale la pena matarte en este último adiós.!",
        "Te quiero, pero...",
        "Cariño, estás muerto otra vez.",
		"Este podría ser tu último juego.",
		
		]

script.registerModule({
    name: '祖安autoL',
    category: 'Fun', 
    description: 'Auto send L.'
}, function (module) {
    module.on('attack', function(e) {
		if (ClassProvider.classProvider.isEntityPlayer(e.getTargetEntity())){
			target = e.getTargetEntity();
		}
    });
    module.on('update', function() {
        if (target != null) {
            if (target.isDead()) {
                mc.thePlayer.sendChatMessage('[Tu amor] L ' + target.getName() + " " + wd[parseInt(Math.random()*wd.length)]);
				target = null;
            };
        };
    });
});